@echo ģ�嵼�뿪ʼ
@echo off
secedit /configure /db bvs.sdb /cfg BVS_2003_ALL.inf /overwrite /quiet
del bvs.sdb
@echo on
@echo ģ�嵼�����

@echo off
:start
SET num=%RANDOM%
SET /A (num%%=1000)
echo %num%
.\WindowsCheck.exe 76c221be-6ab2-ef53-1589-fe16877914e2