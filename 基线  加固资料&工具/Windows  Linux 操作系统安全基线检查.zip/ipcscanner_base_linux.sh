#!/bin/bash
# version=v0.3

pwd=`pwd`
dest_file="$pwd/ipcscanner_base_`date +'%Y-%m-%d_%H-%M-%S'`.csv"
echo "检查结果保存在: $dest_file"

echo -e "检查项目,当前值,标准值,是否合规" > $dest_file

# check /etc/passwd
curr_result=`ls -al /etc/passwd 2>/dev/null | cut -d' ' -f1`
if [ "$curr_result" = "-rw-r--r--" ]; then
    result="是"
else
    result="否"
fi
echo -e "/etc/passwd文件属性,$curr_result,-rw-r--r--,$result" >> $dest_file

# check /etc/shadow
curr_result=`ls -al /etc/shadow 2>/dev/null | cut -d' ' -f1`
if [ "$curr_result" = "-rw-------" ]; then
    result="是"
else
    result="否"
fi
echo -e "/etc/shadow文件属性,$curr_result,-rw-------,$result" >> $dest_file

# check /etc/login.defs
curr_result=`cat /etc/login.defs 2>/dev/null | egrep '^[[:space:]]*PASS_MIN_LEN[[:space:]]*[58][[:space:]]*$'`
if [ "$curr_result" = "" ]; then
    result="否"
else
    result="是"
fi
echo -e "/etc/login.defs配置核查,$curr_result,存在PASS_MIN_LEN 5或PASS_MIN_LEN 8配置行,$result" >> $dest_file

# check /etc/default/login
curr_result=`cat /etc/default/login 2>/dev/null | egrep '^[[:space:]]*SYSLOG[[:space:]]*=[[:space:]]*YES[[:space:]]*$'`
if [ "$curr_result" = "" ]; then
    result="否"
else
    result="是"
fi
echo -e "/etc/default/login配置核查,$curr_result,存在SYSLOG=YES配置行,$result" >> $dest_file

# check /var/adm/loginlog
curr_result=`ls -ald /var/adm/loginlog 2>/dev/null`
if [ "$curr_result" = "" ]; then
    result="否"
else
    result="是"
fi
echo -e "/var/adm/loginlog文件核查,$curr_result,存在/var/adm/loginlog文件,$result" >> $dest_file

